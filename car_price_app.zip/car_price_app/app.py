"""Flask web interface. Run:  python app.py  then open http://127.0.0.1:5000"""
import json
import pickle

import pandas as pd
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
model = pickle.load(open("LinearRegressionModel.pkl", "rb"))
options = json.load(open("options.json"))


@app.route("/")
def home():
    return render_template("index.html", opts=options)


@app.route("/predict", methods=["POST"])
def predict():
    try:
        d = request.get_json()
        row = pd.DataFrame(
            [{
                "name": d["name"],
                "company": d["company"],
                "year": int(d["year"]),
                "kms_driven": int(d["kms_driven"]),
                "fuel_type": d["fuel_type"],
            }]
        )
        price = max(float(model.predict(row)[0]), 0)
        return jsonify(price=round(price), formatted=f"₹ {price:,.0f}")
    except Exception as e:
        return jsonify(error=str(e)), 400


if __name__ == "__main__":
    app.run(debug=True)
