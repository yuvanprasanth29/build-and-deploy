# Used Car Price Predictor (Quikr dataset)

A simple end-to-end ML project: data cleaning → Linear Regression → web interface.

## Structure
```
car_price_app/
├── data/quikr_car.csv      raw dataset
├── train.py                cleans data, trains model, saves .pkl + options.json
├── app.py                  Flask server
├── templates/index.html    the interface
└── requirements.txt
```

## Run it
```bash
pip install -r requirements.txt
python train.py      # creates LinearRegressionModel.pkl and options.json
python app.py        # open http://127.0.0.1:5000
```

## How it works
1. **Clean**: remove non-numeric years, "Ask For Price", bad kms values, missing fuel types; shorten names to 3 words.
2. **Encode**: one-hot encode `name`, `company`, `fuel_type`; pass `year` and `kms_driven` through.
3. **Train**: Linear Regression inside a scikit-learn Pipeline (80/20 split, fixed seed).
4. **Serve**: Flask loads the pipeline; the page sends the form to `/predict` and shows the price.

## Note on accuracy
Expect R² of roughly 0.55–0.75 on unseen data. The original notebook's ~0.92 came from trying 1000
random train/test splits and keeping the luckiest one, which overstates real performance.
