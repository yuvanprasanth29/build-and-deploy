"""Train the Quikr used-car price model.
Follows the notebook: clean data -> one-hot encode -> Linear Regression -> save pipeline.
Run:  python train.py
"""
import json
import pickle

import pandas as pd
from sklearn.compose import make_column_transformer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder

# ---------- 1. Load ----------
car = pd.read_csv("data/quikr_car.csv")
print("Raw shape:", car.shape)

# ---------- 2. Clean (same steps as the notebook) ----------
car = car[car["year"].str.isnumeric()]                      # drop non-year values
car["year"] = car["year"].astype(int)
car = car[car["Price"] != "Ask For Price"]                  # drop missing prices
car["Price"] = car["Price"].str.replace(",", "").astype(int)
car["kms_driven"] = car["kms_driven"].str.split().str.get(0).str.replace(",", "")
car = car[car["kms_driven"].str.isnumeric()]
car["kms_driven"] = car["kms_driven"].astype(int)
car = car[~car["fuel_type"].isna()]
car["name"] = car["name"].str.split().str.slice(0, 3).str.join(" ")  # keep first 3 words
car = car.reset_index(drop=True)
car = car[car["Price"] < 6_000_000]                         # remove extreme outlier
print("Clean shape:", car.shape)
car.to_csv("data/Cleaned_Car_data.csv", index=False)

# ---------- 3. Features / target ----------
X = car[["name", "company", "year", "kms_driven", "fuel_type"]]
y = car["Price"]

# ---------- 4. Model pipeline ----------
transformer = make_column_transformer(
    (OneHotEncoder(handle_unknown="ignore"), ["name", "company", "fuel_type"]),
    remainder="passthrough",
)
pipe = make_pipeline(transformer, LinearRegression())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
pipe.fit(X_train, y_train)
r2 = r2_score(y_test, pipe.predict(X_test))
print(f"R2 score on held-out test set: {r2:.3f}")

# Refit on all data for the final model used by the app
pipe.fit(X, y)
with open("LinearRegressionModel.pkl", "wb") as f:
    pickle.dump(pipe, f)

# ---------- 5. Save dropdown options for the interface ----------
options = {
    "companies": sorted(car["company"].unique().tolist()),
    "models_by_company": {
        c: sorted(g["name"].unique().tolist()) for c, g in car.groupby("company")
    },
    "fuel_types": sorted(car["fuel_type"].unique().tolist()),
    "year_min": int(car["year"].min()),
    "year_max": int(car["year"].max()),
    "r2": round(r2, 3),
}
with open("options.json", "w") as f:
    json.dump(options, f, indent=2)
print("Saved LinearRegressionModel.pkl and options.json")
